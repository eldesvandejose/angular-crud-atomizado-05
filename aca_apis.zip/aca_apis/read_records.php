<?php
  include_once ('db_conn.php');

  // Recuperamos las variables recibidas por GET.
  $criterio = $_GET['criterio'];
  $orden = $_GET['orden'];

  $consulta = "SELECT * FROM socios ";
  $consulta .= "ORDER BY ";
  switch ($criterio) {
    case '1':
      $consulta .= "id ";
      break;
    case '2':
      $consulta .= "doi ";
      break;
    case '3':
      $consulta .= "nombre ";
      break;
    case '4':
      $consulta .= "genero ";
      break;
  }
  $consulta .= ($orden == "5")?"ASC;":"DESC;";
  $hacerConsulta = $conexion->query($consulta);
  $membersArray = $hacerConsulta->fetchAll(PDO::FETCH_ASSOC);
  $hacerConsulta->closeCursor();

  $membersJson = json_encode($membersArray);
  echo $membersJson;
?>
