import { TestBed, inject } from '@angular/core/testing';

import { DataPackService } from './data-pack.service';

describe('DataPackService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DataPackService]
    });
  });

  it('should be created', inject([DataPackService], (service: DataPackService) => {
    expect(service).toBeTruthy();
  }));
});
