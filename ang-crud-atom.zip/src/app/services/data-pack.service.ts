import { Injectable } from '@angular/core';

@Injectable()
export class DataPackService {
  constructor() {}

  public pack(data: any[]) {
    const MyDataPackage = new FormData();
    for (const item of data) {
      // tslint:disable-next-line:forin
      for (const i in item) {
        MyDataPackage.append(i, item[i]);
      }
    }
    return MyDataPackage;
  }
}
